from platform import system

WINDOWS = system() == 'Windows'
LINUX = system() == 'Linux'